document.addEventListener('DOMContentLoaded', function() {
    const coursesBtn = document.getElementById('coursesBtn');
    const coursesDropdown = document.getElementById('coursesDropdown');
    const resourcesBtn = document.getElementById('resourcesBtn');
    const resourcesDropdown = document.getElementById('resourcesDropdown');
    const overlay = document.getElementById('overlay');
    const mainContent = document.querySelector('main');

    function closeDropdowns() {
        coursesDropdown.classList.remove('show');
        resourcesDropdown.classList.remove('show');
        overlay.classList.remove('active');
        mainContent.style.opacity = '1';
    }

    coursesBtn.addEventListener('click', function(event) {
        event.stopPropagation();
        const isShown = coursesDropdown.classList.contains('show');
        closeDropdowns();
        if (!isShown) {
            coursesDropdown.classList.add('show');
            overlay.classList.add('active');
            mainContent.style.opacity = '0.7';
        }
    });

    resourcesBtn.addEventListener('click', function(event) {
        event.stopPropagation();
        const isShown = resourcesDropdown.classList.contains('show');
        closeDropdowns();
        if (!isShown) {
            resourcesDropdown.classList.add('show');
            overlay.classList.add('active');
            mainContent.style.opacity = '0.7';
        }
    });

    overlay.addEventListener('click', function() {
        closeDropdowns();
    });

    document.addEventListener('keydown', function(event) {
        if (event.key === 'Escape') {
            closeDropdowns();
        }
    });
});
